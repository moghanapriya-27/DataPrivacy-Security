/**
 * js/api.js — Shared API helper + password strength utilities
 */
const API_BASE = 'http://localhost:3000/api';

const Auth = {
  getToken()    { return localStorage.getItem('authToken'); },
  setToken(t)   { localStorage.setItem('authToken', t); },
  setPreAuth(t) { localStorage.setItem('preAuthToken', t); },
  getPreAuth()  { return localStorage.getItem('preAuthToken'); },
  clearPreAuth(){ localStorage.removeItem('preAuthToken'); },
  setUser(u)    { localStorage.setItem('currentUser', JSON.stringify(u)); },
  getUser()     { try { return JSON.parse(localStorage.getItem('currentUser')); } catch { return null; } },
  isAuthenticated() { return !!this.getToken(); },
  isAdmin()     { const u = this.getUser(); return u && u.role === 'admin'; },
  logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('preAuthToken');
    localStorage.removeItem('currentUser');
    window.location.href = window.location.pathname.includes('/pages/') ? '../index.html' : 'index.html';
  },
};

async function apiRequest(endpoint, options = {}, usePreAuth = false) {
  const token = usePreAuth ? Auth.getPreAuth() : Auth.getToken();
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers: { ...headers, ...(options.headers || {}) } });
  const data = await res.json();
  if (res.status === 401 && !endpoint.includes('/login') && !endpoint.includes('/register') && !endpoint.includes('/mfa')) {
    Auth.logout();
  }
  return { ok: res.ok, status: res.status, data };
}

function showAlert(id, msg, type = 'error') {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.innerHTML = msg;
  el.classList.remove('hidden');
}
function hideAlert(id) { const el = document.getElementById(id); if (el) el.classList.add('hidden'); }

function requireAuth() {
  if (!Auth.isAuthenticated()) { window.location.href = window.location.pathname.includes('/pages/') ? '../index.html' : 'index.html'; return false; }
  return true;
}
function requireAdmin() {
  if (!requireAuth()) return false;
  if (!Auth.isAdmin()) { window.location.href = 'dashboard.html'; return false; }
  return true;
}

function formatTime(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-IN', { year:'numeric', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit' });
}

function severityBadge(s) {
  const map = { INFO:['badge-info','●'], WARNING:['badge-warning','▲'], CRITICAL:['badge-critical','■'] };
  const [cls,icon] = map[s] || ['badge-info','●'];
  return `<span class="badge ${cls}">${icon} ${s}</span>`;
}
function eventBadge(type) {
  const ok  = ['LOGIN_SUCCESS','MFA_SUCCESS','MFA_SETUP','LOGOUT','REGISTER','ADMIN_ACTION'];
  const bad = ['LOGIN_FAILURE','MFA_FAILURE','MFA_RESET','UNAUTHORIZED'];
  const crit= ['SUSPICIOUS','RATE_LIMITED'];
  if (crit.includes(type)) return `<span class="badge badge-critical">${type}</span>`;
  if (bad.includes(type))  return `<span class="badge badge-warning">${type}</span>`;
  return `<span class="badge badge-success">${type}</span>`;
}

// ── Password strength checker ─────────────────────────────────
function checkPasswordStrength(password) {
  const checks = {
    length:    password.length >= 12,
    upper:     /[A-Z]/.test(password),
    lower:     /[a-z]/.test(password),
    number:    /[0-9]/.test(password),
    special:   /[!@#$%^&*()\-_=+\[\]{};':"\\|,.<>\/?`~]/.test(password),
  };
  const score = Object.values(checks).filter(Boolean).length;
  const pct   = (score / 5) * 100;
  const color = score <= 1 ? '#E8365D' : score === 2 ? '#F5A623' : score === 3 ? '#EAB308' : score === 4 ? '#3B82FF' : '#00C47A';
  const label = score <= 1 ? 'Very Weak' : score === 2 ? 'Weak' : score === 3 ? 'Fair' : score === 4 ? 'Strong' : 'Very Strong';
  return { checks, score, pct, color, label };
}

// ── Attach password strength UI to a field ────────────────────
function attachStrengthMeter(inputId, wrapperId) {
  const input   = document.getElementById(inputId);
  const wrapper = document.getElementById(wrapperId);
  if (!input || !wrapper) return;

  input.addEventListener('input', () => {
    const { checks, pct, color, label } = checkPasswordStrength(input.value);
    const fill = wrapper.querySelector('.pw-strength-fill');
    const lbl  = wrapper.querySelector('.pw-strength-label');
    if (fill) { fill.style.width = pct + '%'; fill.style.background = color; }
    if (lbl)  { lbl.textContent = input.value ? label : ''; lbl.style.color = color; }
    Object.entries(checks).forEach(([key, met]) => {
      const el = wrapper.querySelector(`[data-req="${key}"]`);
      if (el) el.className = 'pw-req ' + (met ? 'met' : '');
    });
  });
}

// ── Eye toggle for password fields ───────────────────────────
function attachEyeToggle(inputId, btnId) {
  const input = document.getElementById(inputId);
  const btn   = document.getElementById(btnId);
  if (!input || !btn) return;
  btn.addEventListener('click', () => {
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.innerHTML = show ? '🙈' : '👁';
    btn.title = show ? 'Hide password' : 'Show password';
  });
}

// ── Sidebar user info helper ──────────────────────────────────
function populateSidebar() {
  const user = Auth.getUser();
  if (!user) return;
  const name   = document.getElementById('sidebarUserName');
  const avatar = document.getElementById('sidebarAvatar');
  const role   = document.getElementById('sidebarRole');
  if (name)   name.textContent   = user.fullName || user.username;
  if (avatar) { avatar.textContent = (user.fullName || user.username)[0].toUpperCase(); avatar.className = `user-avatar role-${user.role}`; }
  if (role)   role.textContent   = user.role === 'admin' ? '👑 Administrator' : 'Security Operator';
}
