/**
 * controllers/siemController.js — SIEM stats + logs (admin only)
 */
const { Logs } = require('../models/db');

function getLogs(req, res) {
  const { type = 'all', severity = 'all', limit = 200 } = req.query;
  const logs = Logs.getFiltered({ type: type === 'all' ? null : type,
                                   severity: severity === 'all' ? null : severity,
                                   limit });
  res.json({ success: true, logs });
}

function getStats(req, res) {
  const all = Logs.getAll();
  const stats = {
    total:        all.length,
    loginSuccess: all.filter(l => l.type === 'LOGIN_SUCCESS').length,
    loginFailure: all.filter(l => l.type === 'LOGIN_FAILURE').length,
    mfaSuccess:   all.filter(l => l.type === 'MFA_SUCCESS').length,
    mfaFailure:   all.filter(l => l.type === 'MFA_FAILURE').length,
    suspicious:   all.filter(l => l.type === 'SUSPICIOUS').length,
    rateLimited:  all.filter(l => l.type === 'RATE_LIMITED').length,
    critical:     all.filter(l => l.severity === 'CRITICAL').length,
    warning:      all.filter(l => l.severity === 'WARNING').length,
    info:         all.filter(l => l.severity === 'INFO').length,
  };

  const now = new Date();
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    const ds = d.toISOString().split('T')[0];
    const dl = all.filter(l => l.timestamp.startsWith(ds));
    days.push({
      date: ds,
      label: d.toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric' }),
      success:  dl.filter(l => l.severity === 'INFO').length,
      warning:  dl.filter(l => l.severity === 'WARNING').length,
      critical: dl.filter(l => l.severity === 'CRITICAL').length,
    });
  }
  res.json({ success: true, stats, timeline: days });
}

module.exports = { getLogs, getStats };
