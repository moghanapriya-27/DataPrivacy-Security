/**
 * controllers/adminController.js
 * Admin-only endpoints: user list, per-user logs, attempt counts, login activity logs
 */
const { Users, Logs, Attempts } = require('../models/db');
const { logEvent, EVENT_TYPES } = require('../models/logger');

// ── List all users (safe fields) ──────────────────────────────
function listUsers(req, res) {
  const users = Users.getSafeList();
  const attempts = Attempts.getAll();
  const enriched = users.map(u => ({
    ...u,
    failedAttempts: attempts[u.username]?.count || 0,
    lastAttempt:    attempts[u.username]?.lastAttempt || null,
  }));
  res.json({ success: true, users: enriched });
}

// ── Get logs for a specific user ──────────────────────────────
function getUserLogs(req, res) {
  const { username } = req.params;
  const { limit = 100 } = req.query;
  const logs = Logs.getFiltered({ username, limit });
  logEvent(EVENT_TYPES.ADMIN_ACTION, {
    username: req.user.username,
    ip: req.ip,
    details: `Admin viewed logs for user: ${username}`
  });
  res.json({ success: true, logs, targetUser: username });
}

// ── Get attempt stats for all users ──────────────────────────
function getAttemptStats(req, res) {
  const attempts = Attempts.getAll();
  const users    = Users.getSafeList();
  const stats = users.map(u => ({
    username:       u.username,
    fullName:       u.fullName,
    role:           u.role,
    mfaEnabled:     u.mfaEnabled,
    lastLogin:      u.lastLogin,
    failedAttempts: attempts[u.username]?.count || 0,
    lastAttempt:    attempts[u.username]?.lastAttempt || null,
    riskLevel:      (attempts[u.username]?.count || 0) >= 5 ? 'HIGH' :
                    (attempts[u.username]?.count || 0) >= 3 ? 'MEDIUM' : 'LOW',
  }));
  res.json({ success: true, stats });
}

// ── Reset a user's failed attempt counter ─────────────────────
function resetAttempts(req, res) {
  const { username } = req.params;
  Attempts.reset(username);
  logEvent(EVENT_TYPES.ADMIN_ACTION, {
    username: req.user.username,
    ip: req.ip,
    details: `Admin reset attempt counter for: ${username}`
  });
  res.json({ success: true, message: `Attempts reset for ${username}` });
}

// ── Get login activity logs (LOGIN_SUCCESS, LOGIN_FAILURE, MFA_SUCCESS, MFA_FAILURE, LOGOUT) ──
function getLoginActivityLogs(req, res) {
  const { username, limit = 500 } = req.query;
  const LOGIN_TYPES = [
    'LOGIN_SUCCESS', 'LOGIN_FAILURE',
    'MFA_SUCCESS',   'MFA_FAILURE',
    'LOGOUT',        'SUSPICIOUS',
    'RATE_LIMITED',
  ];
  let logs = Logs.getAll();
  // Filter to login-related events only
  logs = logs.filter(l => LOGIN_TYPES.includes(l.type));
  // Optionally filter by username
  if (username && username !== 'all') {
    logs = logs.filter(l => l.username === username);
  }
  logs = logs.slice(0, parseInt(limit));

  // Build per-user summary
  const users = Users.getSafeList();
  const summary = users.map(u => {
    const userLogs = logs.filter(l => l.username === u.username);
    return {
      username:     u.username,
      fullName:     u.fullName,
      role:         u.role,
      mfaEnabled:   u.mfaEnabled,
      lastLogin:    u.lastLogin,
      loginSuccess: userLogs.filter(l => l.type === 'LOGIN_SUCCESS').length,
      loginFailure: userLogs.filter(l => l.type === 'LOGIN_FAILURE').length,
      mfaSuccess:   userLogs.filter(l => l.type === 'MFA_SUCCESS').length,
      mfaFailure:   userLogs.filter(l => l.type === 'MFA_FAILURE').length,
      suspicious:   userLogs.filter(l => l.type === 'SUSPICIOUS').length,
      totalEvents:  userLogs.length,
    };
  });

  logEvent(EVENT_TYPES.ADMIN_ACTION, {
    username: req.user.username,
    ip: req.ip,
    details: `Admin viewed login activity logs${username ? ` for user: ${username}` : ' (all users)'}`
  });

  res.json({ success: true, logs, summary });
}

module.exports = { listUsers, getUserLogs, getAttemptStats, resetAttempts, getLoginActivityLogs };
