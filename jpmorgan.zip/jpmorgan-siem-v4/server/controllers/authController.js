/**
 * controllers/authController.js
 * Full auth: register, login, MFA setup/confirm/verify/reset, getMe
 * NEW: role field, strong password validation, attempt tracking
 */
const bcrypt    = require('bcryptjs');
const speakeasy = require('speakeasy');
const QRCode    = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const { Users, Attempts } = require('../models/db');
const { logEvent, EVENT_TYPES } = require('../models/logger');
const { generateToken } = require('../middleware/auth');

const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS) || 12;
const TOTP_APP_NAME = process.env.TOTP_APP_NAME || 'JPMorganSIEM';

// ── Strong password validator ─────────────────────────────────
function validatePassword(password) {
  const errors = [];
  if (password.length < 12)              errors.push('At least 12 characters');
  if (!/[A-Z]/.test(password))           errors.push('At least one uppercase letter (A-Z)');
  if (!/[a-z]/.test(password))           errors.push('At least one lowercase letter (a-z)');
  if (!/[0-9]/.test(password))           errors.push('At least one number (0-9)');
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/.test(password))
                                          errors.push('At least one special character (!@#$%^&* etc.)');
  // Common weak patterns
  if (/^(.)\1+$/.test(password))         errors.push('Cannot be all the same character');
  if (/password/i.test(password))        errors.push('Cannot contain the word "password"');
  return errors;
}

// ── REGISTER ─────────────────────────────────────────────────
async function register(req, res) {
  const { username, password, fullName, role } = req.body;
  const ip = req.ip || req.connection.remoteAddress;

  if (!username || !password || !fullName) {
    return res.status(400).json({ success: false, message: 'All fields are required.' });
  }
  if (username.length < 3 || username.length > 32) {
    return res.status(400).json({ success: false, message: 'Username must be 3–32 characters.' });
  }
  if (!/^[a-zA-Z0-9_]+$/.test(username)) {
    return res.status(400).json({ success: false, message: 'Username: letters, numbers, underscores only.' });
  }

  // Strong password check
  const pwErrors = validatePassword(password);
  if (pwErrors.length > 0) {
    return res.status(400).json({ success: false, message: 'Password too weak: ' + pwErrors.join('; ') });
  }

  if (Users.findByUsername(username)) {
    return res.status(409).json({ success: false, message: 'Username already exists.' });
  }

  // Only allow role 'user' via self-registration; 'admin' is set manually or via seed
  const assignedRole = (role === 'admin') ? 'user' : (role || 'user');

  const hashedPassword = await bcrypt.hash(password, BCRYPT_ROUNDS);
  const newUser = {
    id:           uuidv4(),
    username,
    fullName,
    role:         assignedRole,
    passwordHash: hashedPassword,
    mfaEnabled:   false,
    mfaSecret:    null,
    tempMfaSecret:null,
    createdAt:    new Date().toISOString(),
    lastLogin:    null,
  };

  Users.create(newUser);
  logEvent(EVENT_TYPES.REGISTER, { username, ip, details: `New ${assignedRole} registered` });
  res.json({ success: true, message: 'Account created. Please log in.' });
}

// ── LOGIN ─────────────────────────────────────────────────────
async function login(req, res) {
  const { username, password } = req.body;
  const ip = req.ip || req.connection.remoteAddress;

  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required.' });
  }

  const user = Users.findByUsername(username);
  if (!user) {
    Attempts.increment(username);
    logEvent(EVENT_TYPES.LOGIN_FAILURE, { username, ip, details: 'User not found' });
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    const att = Attempts.increment(username);
    logEvent(EVENT_TYPES.LOGIN_FAILURE, { username, ip, details: `Wrong password (attempt #${att.count})` });
    if (att.count >= 5) {
      logEvent(EVENT_TYPES.SUSPICIOUS, { username, ip, details: `${att.count} consecutive failed logins` });
    }
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }

  // Successful — reset attempt counter
  Attempts.reset(username);
  logEvent(EVENT_TYPES.LOGIN_SUCCESS, { username, ip, details: 'Password verified' });

  if (!user.mfaEnabled) {
    const preAuthToken = generateToken({ username, role: user.role, stage: 'pre-mfa-setup' });
    return res.json({ success: true, status: 'setup_required', preAuthToken });
  }

  const preAuthToken = generateToken({ username, role: user.role, stage: 'pre-mfa-verify' });
  return res.json({ success: true, status: 'mfa_required', preAuthToken });
}

// ── MFA SETUP ─────────────────────────────────────────────────
async function setupMFA(req, res) {
  const { username, stage } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (stage !== 'pre-mfa-setup') {
    return res.status(403).json({ success: false, message: 'Invalid setup stage.' });
  }

  const user = Users.findByUsername(username);
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

  const secret = speakeasy.generateSecret({
    length: 32,
    name:   `${TOTP_APP_NAME} (${username})`,
    issuer: TOTP_APP_NAME,
  });

  Users.update(username, { tempMfaSecret: secret.base32 });

  // QR code only — no manual secret exposed to client
  const qrDataUrl = await QRCode.toDataURL(secret.otpauth_url, {
    width: 200,
    margin: 2,
    color: { dark: '#000000', light: '#ffffff' }
  });

  logEvent(EVENT_TYPES.MFA_SETUP, { username, ip, details: 'MFA setup initiated — QR generated' });

  // Return ONLY the QR image, never the raw secret
  res.json({ success: true, qr: qrDataUrl });
}

// ── MFA CONFIRM ───────────────────────────────────────────────
function confirmMFA(req, res) {
  const { username, role, stage } = req.user;
  const { token } = req.body;
  const ip = req.ip || req.connection.remoteAddress;

  if (stage !== 'pre-mfa-setup') {
    return res.status(403).json({ success: false, message: 'Invalid stage.' });
  }

  const user = Users.findByUsername(username);
  if (!user || !user.tempMfaSecret) {
    return res.status(400).json({ success: false, message: 'No pending MFA setup.' });
  }

  const verified = speakeasy.totp.verify({
    secret: user.tempMfaSecret, encoding: 'base32',
    token: String(token), window: 1,
  });

  if (!verified) {
    logEvent(EVENT_TYPES.MFA_FAILURE, { username, ip, details: 'MFA confirm failed — wrong OTP' });
    return res.status(401).json({ success: false, message: 'Invalid OTP. Please try again.' });
  }

  Users.update(username, {
    mfaSecret: user.tempMfaSecret, tempMfaSecret: null,
    mfaEnabled: true, lastLogin: new Date().toISOString(),
  });

  logEvent(EVENT_TYPES.MFA_SUCCESS, { username, ip, details: 'MFA setup confirmed' });

  const authToken = generateToken({ username, role, stage: 'authenticated' });
  res.json({ success: true, authToken, role, message: 'MFA enabled successfully!' });
}

// ── MFA VERIFY ────────────────────────────────────────────────
function verifyMFA(req, res) {
  const { username, role, stage } = req.user;
  const { token } = req.body;
  const ip = req.ip || req.connection.remoteAddress;

  if (stage !== 'pre-mfa-verify') {
    return res.status(403).json({ success: false, message: 'Invalid auth stage.' });
  }

  const user = Users.findByUsername(username);
  if (!user || !user.mfaSecret) {
    return res.status(400).json({ success: false, message: 'MFA not configured.' });
  }

  const verified = speakeasy.totp.verify({
    secret: user.mfaSecret, encoding: 'base32',
    token: String(token), window: 1,
  });

  if (!verified) {
    logEvent(EVENT_TYPES.MFA_FAILURE, { username, ip, details: 'Wrong OTP on login' });
    return res.status(401).json({ success: false, message: 'Invalid OTP. Please try again.' });
  }

  Users.update(username, { lastLogin: new Date().toISOString() });
  Attempts.reset(username);
  logEvent(EVENT_TYPES.MFA_SUCCESS, { username, ip, details: 'Login MFA verified' });

  const authToken = generateToken({ username, role, stage: 'authenticated' });
  res.json({ success: true, authToken, role });
}

// ── MFA RESET ─────────────────────────────────────────────────
function resetMFA(req, res) {
  const { username, stage } = req.user;
  const ip = req.ip || req.connection.remoteAddress;

  if (stage !== 'authenticated') {
    return res.status(403).json({ success: false, message: 'Full authentication required.' });
  }

  Users.update(username, { mfaEnabled: false, mfaSecret: null, tempMfaSecret: null });
  logEvent(EVENT_TYPES.MFA_RESET, { username, ip, details: 'MFA reset by user' });
  res.json({ success: true, message: 'MFA reset. Set up again on next login.' });
}

// ── GET ME ────────────────────────────────────────────────────
function getMe(req, res) {
  const { username } = req.user;
  const user = Users.findByUsername(username);
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
  res.json({
    success: true,
    user: {
      username: user.username, fullName: user.fullName,
      role: user.role, mfaEnabled: user.mfaEnabled,
      createdAt: user.createdAt, lastLogin: user.lastLogin,
    }
  });
}

module.exports = { register, login, setupMFA, confirmMFA, verifyMFA, resetMFA, getMe };
