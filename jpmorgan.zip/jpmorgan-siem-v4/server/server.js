/**
 * server.js — JP Morgan Chase SIEM + MFA v3
 * Role-based access: admin sees SIEM/user logs; operators see dashboard only
 */
require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const express = require('express');
const cors    = require('cors');
const path    = require('path');
const bcrypt  = require('bcryptjs');

const authRoutes  = require('./routes/auth');
const siemRoutes  = require('./routes/siem');
const adminRoutes = require('./routes/admin');
const { Users }   = require('./models/db');

const app = express();

// ── Security Headers ──────────────────────────────────────────
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

app.use(cors({ origin: '*', methods: ['GET','POST','PUT','DELETE'], allowedHeaders: ['Content-Type','Authorization'] }));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, '../client')));

// ── Routes ────────────────────────────────────────────────────
app.use('/api/auth',  authRoutes);
app.use('/api/siem',  siemRoutes);
app.use('/api/admin', adminRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));
app.use((req, res) => res.status(404).json({ success: false, message: 'Endpoint not found.' }));
app.use((err, req, res, next) => { console.error(err.message); res.status(500).json({ success: false, message: 'Internal server error.' }); });

// ── Seed admin account on first run ──────────────────────────
async function seedAdmin() {
  const adminUsername = process.env.ADMIN_USERNAME || 'admin';
  if (!Users.findByUsername(adminUsername)) {
    const { v4: uuidv4 } = require('uuid');
    const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@SecurePass#2024', 12);
    Users.create({
      id: uuidv4(), username: adminUsername, fullName: 'System Administrator',
      role: 'admin', passwordHash: hash,
      mfaEnabled: false, mfaSecret: null, tempMfaSecret: null,
      createdAt: new Date().toISOString(), lastLogin: null,
    });
    console.log(`\n✅ Admin account seeded — username: ${adminUsername}`);
    console.log(`   Password: ${process.env.ADMIN_PASSWORD || 'Admin@SecurePass#2024'}\n`);
  }
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  await seedAdmin();
  console.log('');
  console.log('╔══════════════════════════════════════════════════════╗');
  console.log('║    JP Morgan Chase  SIEM + MFA System  v3.0          ║');
  console.log('╠══════════════════════════════════════════════════════╣');
  console.log(`║  Server → http://localhost:${PORT}                       ║`);
  console.log('║  Open client/index.html in your browser              ║');
  console.log('║  Admin login: admin / Admin@SecurePass#2024           ║');
  console.log('╚══════════════════════════════════════════════════════╝');
});
