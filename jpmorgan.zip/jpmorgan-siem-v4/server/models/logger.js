/**
 * models/logger.js — SIEM Event Logger
 */
const { v4: uuidv4 } = require('uuid');
const { Logs } = require('./db');

const EVENT_TYPES = {
  LOGIN_SUCCESS:   'LOGIN_SUCCESS',
  LOGIN_FAILURE:   'LOGIN_FAILURE',
  MFA_SUCCESS:     'MFA_SUCCESS',
  MFA_FAILURE:     'MFA_FAILURE',
  MFA_SETUP:       'MFA_SETUP',
  MFA_RESET:       'MFA_RESET',
  SUSPICIOUS:      'SUSPICIOUS',
  RATE_LIMITED:    'RATE_LIMITED',
  UNAUTHORIZED:    'UNAUTHORIZED',
  LOGOUT:          'LOGOUT',
  ADMIN_ACTION:    'ADMIN_ACTION',
  REGISTER:        'REGISTER',
};

const SEVERITY = { INFO: 'INFO', WARNING: 'WARNING', CRITICAL: 'CRITICAL' };

const EVENT_SEVERITY = {
  LOGIN_SUCCESS:  'INFO',
  LOGIN_FAILURE:  'WARNING',
  MFA_SUCCESS:    'INFO',
  MFA_FAILURE:    'WARNING',
  MFA_SETUP:      'INFO',
  MFA_RESET:      'WARNING',
  SUSPICIOUS:     'CRITICAL',
  RATE_LIMITED:   'CRITICAL',
  UNAUTHORIZED:   'WARNING',
  LOGOUT:         'INFO',
  ADMIN_ACTION:   'INFO',
  REGISTER:       'INFO',
};

function logEvent(eventType, meta = {}) {
  const entry = {
    id:        uuidv4(),
    type:      eventType,
    severity:  EVENT_SEVERITY[eventType] || 'INFO',
    timestamp: new Date().toISOString(),
    username:  meta.username || 'anonymous',
    ip:        meta.ip || 'unknown',
    details:   meta.details || '',
  };
  Logs.add(entry);
  const icon = entry.severity === 'CRITICAL' ? '🔴' : entry.severity === 'WARNING' ? '🟡' : '🟢';
  console.log(`${icon} [SIEM] ${entry.timestamp} | ${entry.type} | user=${entry.username} | ip=${entry.ip}`);
  return entry;
}

module.exports = { logEvent, EVENT_TYPES, SEVERITY };
