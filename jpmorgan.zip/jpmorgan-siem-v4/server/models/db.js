/**
 * models/db.js — JSON File Database
 * Supports: users (with role), logs (with per-user attempt tracking)
 */
const fs   = require('fs');
const path = require('path');

const USERS_FILE    = path.join(__dirname, '../data/users.json');
const LOGS_FILE     = path.join(__dirname, '../data/logs.json');
const ATTEMPTS_FILE = path.join(__dirname, '../data/attempts.json');

function ensureFile(filePath, def) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify(def, null, 2));
}
ensureFile(USERS_FILE,    []);
ensureFile(LOGS_FILE,     []);
ensureFile(ATTEMPTS_FILE, {});

function readJSON(f) {
  try { return JSON.parse(fs.readFileSync(f, 'utf-8')); }
  catch { return Array.isArray([]) ? [] : {}; }
}
function writeJSON(f, d) { fs.writeFileSync(f, JSON.stringify(d, null, 2)); }

// ── USERS ─────────────────────────────────────────────────────
const Users = {
  getAll()              { return readJSON(USERS_FILE); },
  findByUsername(u)     { return readJSON(USERS_FILE).find(x => x.username === u) || null; },
  findById(id)          { return readJSON(USERS_FILE).find(x => x.id === id) || null; },
  create(data)          { const u = readJSON(USERS_FILE); u.push(data); writeJSON(USERS_FILE, u); return data; },
  update(username, upd) {
    const u = readJSON(USERS_FILE);
    const i = u.findIndex(x => x.username === username);
    if (i === -1) return null;
    u[i] = { ...u[i], ...upd };
    writeJSON(USERS_FILE, u);
    return u[i];
  },
  getSafeList() {
    // Returns list safe for admin view (no secrets)
    return readJSON(USERS_FILE).map(u => ({
      id: u.id, username: u.username, fullName: u.fullName,
      role: u.role, mfaEnabled: u.mfaEnabled,
      createdAt: u.createdAt, lastLogin: u.lastLogin
    }));
  }
};

// ── LOGS ──────────────────────────────────────────────────────
const Logs = {
  getAll()   { return readJSON(LOGS_FILE); },
  add(entry) {
    const logs = readJSON(LOGS_FILE);
    logs.unshift(entry);
    if (logs.length > 2000) logs.splice(2000);
    writeJSON(LOGS_FILE, logs);
    return entry;
  },
  getFiltered({ type, severity, username, limit = 200 }) {
    let logs = readJSON(LOGS_FILE);
    if (type && type !== 'all')         logs = logs.filter(l => l.type === type);
    if (severity && severity !== 'all') logs = logs.filter(l => l.severity === severity);
    if (username)                       logs = logs.filter(l => l.username === username);
    return logs.slice(0, parseInt(limit));
  }
};

// ── ATTEMPT TRACKER (per-user login fail counts) ─────────────
const Attempts = {
  get(username) {
    const a = readJSON(ATTEMPTS_FILE);
    return a[username] || { count: 0, lastAttempt: null };
  },
  increment(username) {
    const a = readJSON(ATTEMPTS_FILE);
    if (!a[username]) a[username] = { count: 0, lastAttempt: null };
    a[username].count++;
    a[username].lastAttempt = new Date().toISOString();
    writeJSON(ATTEMPTS_FILE, a);
    return a[username];
  },
  reset(username) {
    const a = readJSON(ATTEMPTS_FILE);
    a[username] = { count: 0, lastAttempt: null };
    writeJSON(ATTEMPTS_FILE, a);
  },
  getAll() { return readJSON(ATTEMPTS_FILE); }
};

module.exports = { Users, Logs, Attempts };
