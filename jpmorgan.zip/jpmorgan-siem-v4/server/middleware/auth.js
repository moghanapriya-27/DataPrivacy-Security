/**
 * middleware/auth.js — JWT Auth + Role Guards
 */
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_dev_secret';

function requireAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });
  }
  const token = authHeader.split(' ')[1];
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ success: false, message: 'Invalid or expired token. Please log in again.' });
  }
}

// Only allow admin role
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Access denied. Admin role required.' });
  }
  next();
}

// Only allow authenticated stage (not pre-auth)
function requireFullAuth(req, res, next) {
  if (!req.user || req.user.stage !== 'authenticated') {
    return res.status(403).json({ success: false, message: 'Full authentication required.' });
  }
  next();
}

function generateToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRY || '8h' });
}

module.exports = { requireAuth, requireAdmin, requireFullAuth, generateToken };
