/**
 * middleware/rateLimiter.js
 */
const rateLimit = require('express-rate-limit');
const { logEvent, EVENT_TYPES } = require('../models/logger');

const authLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 10,
  standardHeaders: true, legacyHeaders: false,
  handler: (req, res) => {
    logEvent(EVENT_TYPES.RATE_LIMITED, {
      username: req.body?.username || 'unknown',
      ip: req.ip || req.connection.remoteAddress,
      details: `Rate limit exceeded on ${req.path}`,
    });
    res.status(429).json({ success: false, message: 'Too many attempts. Please wait 15 minutes.' });
  },
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, max: 120,
  message: { success: false, message: 'Too many requests.' }
});

module.exports = { authLimiter, apiLimiter };
