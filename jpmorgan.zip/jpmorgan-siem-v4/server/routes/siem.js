const express = require('express');
const router  = express.Router();
const { getLogs, getStats } = require('../controllers/siemController');
const { requireAuth, requireAdmin, requireFullAuth } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');

// SIEM routes — admin only + fully authenticated
router.get('/logs',  requireAuth, requireFullAuth, requireAdmin, apiLimiter, getLogs);
router.get('/stats', requireAuth, requireFullAuth, requireAdmin, apiLimiter, getStats);
module.exports = router;
