const express = require('express');
const router  = express.Router();
const { register, login, setupMFA, confirmMFA, verifyMFA, resetMFA, getMe } = require('../controllers/authController');
const { requireAuth, requireFullAuth } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');

router.post('/register',     authLimiter, register);
router.post('/login',        authLimiter, login);
router.post('/mfa/setup',    requireAuth, setupMFA);
router.post('/mfa/confirm',  requireAuth, confirmMFA);
router.post('/mfa/verify',   requireAuth, verifyMFA);
router.post('/mfa/reset',    requireAuth, requireFullAuth, resetMFA);
router.get('/me',            requireAuth, requireFullAuth, getMe);
module.exports = router;
