const express = require('express');
const router  = express.Router();
const { listUsers, getUserLogs, getAttemptStats, resetAttempts, getLoginActivityLogs } = require('../controllers/adminController');
const { requireAuth, requireAdmin, requireFullAuth } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');

// All admin routes require full auth + admin role
router.use(requireAuth, requireFullAuth, requireAdmin, apiLimiter);

router.get('/users',                              listUsers);
router.get('/users/:username/logs',               getUserLogs);
router.get('/attempts',                           getAttemptStats);
router.post('/users/:username/reset-attempts',    resetAttempts);

// NEW: Login activity logs — admin only
router.get('/login-activity',                     getLoginActivityLogs);

module.exports = router;
