# 🏦 JP Morgan Chase — SIEM + MFA Security System v3.0

## What's New in v3 (Fixes Applied)

| Issue | Fix |
|---|---|
| No password visibility toggle | 👁 Eye button on all password fields |
| Weak passwords allowed | 12+ chars, uppercase, lowercase, number, special char enforced |
| Manual secret key shown alongside QR | QR code ONLY — no text key exposed |
| No role-based access | `admin` role sees SIEM; `user` role sees only their dashboard |
| No per-user attempt tracking | Admin sees failed attempt counts + risk level per user |
| Password suggestions shown | Strength meter shows checklist, not suggestions |
| Anyone could see SIEM logs | SIEM/logs routes require `requireAdmin` middleware |

---

## 🚀 Setup (VS Code — 3 steps)

### 1. Install dependencies
```
cd server
npm install
```

### 2. Start the server
```
node server.js
```

### 3. Open the app
Open `client/index.html` in your browser.

---

## 🔑 Default Admin Account
```
Username : admin
Password : Admin@SecurePass#2024
```
On first run the server auto-creates this admin account.

---

## 👥 Role-Based Access

| Feature | Admin | User/Operator |
|---|---|---|
| Login + MFA | ✅ | ✅ |
| My Dashboard | ✅ | ✅ |
| My Profile | ✅ | ✅ |
| SIEM Event Logs | ✅ | ❌ 403 |
| SIEM Dashboard (charts) | ✅ | ❌ 403 |
| User Management | ✅ | ❌ 403 |
| Per-user log viewer | ✅ | ❌ 403 |
| Attempt reset | ✅ | ❌ 403 |

---

## 🔐 MFA Flow

```
First Login:
  Enter credentials → /api/auth/login (status: setup_required)
  → mfa-setup.html  (QR code generated — shown ONCE, no text key)
  → Scan with Google Authenticator
  → Enter OTP → /api/auth/mfa/confirm
  → Full JWT issued → admin.html OR dashboard.html (by role)

Subsequent Logins:
  Enter credentials → /api/auth/login (status: mfa_required)
  → mfa-verify.html
  → Enter OTP → /api/auth/mfa/verify
  → Full JWT issued → redirect by role
```

---

## 🔒 Strong Password Policy
All passwords must have:
- Minimum 12 characters
- At least 1 uppercase letter (A-Z)
- At least 1 lowercase letter (a-z)
- At least 1 number (0-9)
- At least 1 special character (!@#$%^&* etc.)

Enforced on **both** client (strength meter) and **server** (validation).

---

## 📁 Project Structure
```
jpmorgan-siem-v2/
├── server/
│   ├── server.js                ← Express + admin auto-seed
│   ├── .env                     ← Config + default admin creds
│   ├── package.json
│   ├── data/
│   │   ├── users.json           ← Auto-created
│   │   ├── logs.json            ← Auto-created
│   │   └── attempts.json        ← Auto-created (per-user fail counts)
│   ├── controllers/
│   │   ├── authController.js    ← Auth + strong PW validation + QR only
│   │   ├── siemController.js    ← SIEM stats/logs (admin only)
│   │   └── adminController.js   ← User list, per-user logs, attempt reset
│   ├── middleware/
│   │   ├── auth.js              ← requireAuth, requireAdmin, requireFullAuth
│   │   └── rateLimiter.js
│   ├── models/
│   │   ├── db.js                ← users + logs + attempts
│   │   └── logger.js
│   └── routes/
│       ├── auth.js
│       ├── siem.js              ← Admin only
│       └── admin.js             ← Admin only
│
└── client/
    ├── index.html               ← Login (eye toggle)
    ├── css/style.css
    ├── js/api.js                ← PW strength, eye toggle, role helpers
    └── pages/
        ├── register.html        ← Strength meter + eye + match check
        ├── mfa-setup.html       ← QR only (no text key)
        ├── mfa-verify.html      ← OTP verify
        ├── dashboard.html       ← Operator view (no SIEM access)
        ├── admin.html           ← Admin SIEM dashboard + risk table
        ├── siem.html            ← Full SIEM log table (admin)
        ├── admin-users.html     ← User management (admin)
        ├── user-logs.html       ← Per-user SIEM logs (admin)
        └── profile.html         ← Shared — adapts nav by role
```

---

## 🔐 Login Activity Logs (v4 Addition)

### Feature Overview
A dedicated **Login Activity Logs** page accessible **only by admin users**.

### What it shows
- **Per-User Summary cards** — per user: login successes, failures, MFA events, suspicious activity count, last login
- **All Login Events table** — filterable by user, event type, severity, IP / details search
- Covers event types: `LOGIN_SUCCESS`, `LOGIN_FAILURE`, `MFA_SUCCESS`, `MFA_FAILURE`, `SUSPICIOUS`, `RATE_LIMITED`, `LOGOUT`

### How admin-only access is enforced

#### Server-side (primary guard — cannot be bypassed)
1. `requireAuth` — validates the JWT token in the `Authorization` header
2. `requireFullAuth` — ensures the token stage is `authenticated` (not pre-MFA)
3. `requireAdmin` — checks `req.user.role === 'admin'`; returns **403 Forbidden** if not

All three middleware functions run on every `/api/admin/*` route.

#### Client-side (UX guard)
- `requireAdmin()` in `api.js` checks the role stored in `localStorage`
- If not admin, the user is redirected to `dashboard.html` immediately
- Non-admin users never see the page or its nav link

### New API endpoint
```
GET /api/admin/login-activity?limit=500&username=<optional>
```
Returns `{ logs: [...], summary: [...] }` — **403** for non-admins.

### Navigation
The Login Activity page appears in the Admin sidebar on:
- Admin Dashboard (`admin.html`)
- All Event Logs (`siem.html`)
- User Management (`admin-users.html`)
- User Logs (`user-logs.html`)
